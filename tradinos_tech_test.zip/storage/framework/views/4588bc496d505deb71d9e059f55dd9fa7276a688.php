<?php $__env->startSection('content'); ?>
    
    
    
    
    

    
    
    
    
    
    

    
    
    
    
    
    
    <?php echo e(dd($data)); ?>

    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="fa fa-product-hunt icon-gradient bg-warm-coders">
                        </i>
                    </div>
                    <div>Products Table
                    </div>
                </div>
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="page-title-actions">
                            <a href="<?php echo e(route('tasks.create')); ?>"  data-toggle="tooltip" title="create a new product"
                               data-placement="bottom"
                               class="btn-shadow mr-3 btn bg-warm-coders text-white btn-lg font-weight-bold">Add Task
                                <i class="fa fa-plus-square text-white"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="main-card mb-3 card">
                    <div class="card-body" id="table_data">
                        <?php echo $__env->make('tasks_rows', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function(){

            $(document).on('click', '.page-link', function(event){
                event.preventDefault();
                var page = $(this).attr('href').split('page=')[1];
                fetch_data(page);
            });

            function fetch_data(page)
            {
                var _token = $("input[name=_token]").val();
                $.ajax({
                    url:"<?php echo e(route('tasks.get')); ?>",
                    method:"GET",
                    data:{
                        _token: "<?php echo e(csrf_token()); ?>",
                        page:page},
                    success:function(data)
                    {
                        $('#table_data').html(data);
                    }
                });
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\tradinos_tech_test\resources\views/index.blade.php ENDPATH**/ ?>