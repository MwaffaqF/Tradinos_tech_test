<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Tradinos')); ?></title>

    <!-- Scripts -->


<!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/base.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
</head>
<link href="<?php echo e(asset('/css/fontawsome/fontawsome.min.css')); ?>" rel="stylesheet" type="text/css">

<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/jquery-ui.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/bootstrap.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/perfect-scrollable.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/scrollbar.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/metismenu.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/blockui.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/axios.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/charts/apex-charts.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/picker.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/picker.date.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/charts/chart.bundle.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/charts/chart.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/form-components/form-wizard.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/form-components/bootstrap-editable.js')); ?>"></script>

<script type="text/javascript"
        src="<?php echo e(asset('/js/template/vendors/form-components/bootstrap-multiselect.js')); ?>"></script>
<script type="text/javascript"
        src="<?php echo e(asset('/js/template/vendors/jquery-contextmenu/jquery-contextmenu.min.js')); ?>"></script>
<script type="text/javascript"
        src="<?php echo e(asset('/js/template/vendors/jquery-contextmenu/jquery.ui.position.js')); ?>"></script>


<script type="text/javascript"
        src="<?php echo e(asset('/js/template/vendors/tables.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/form-components/form-wizard.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/template/scripts-init/datepicker.init.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/blockui.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/app.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/form_floating_labels.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/pickerdate.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/summernote/summernote-lite.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/toastr.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/vendors/carousel-slider.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/template/scripts-init/carousel-slider.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-header" id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a href="<?php echo e(url('/home')); ?>" class="link_logo_header navbar-brand">
                    <img class="app-logo" src="<?php echo e(asset('/svg/tradinos_logo_horizontal_dark_blue.svg')); ?>" alt="">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="app-main ">
            <div class="app-main__outer">
                <?php echo $__env->yieldContent('content'); ?>

                <div class="app-wrapper-footer ">
                    <div class="app-footer">
                        <div class="app-footer__inner">
                            <div class="margin-h-center">
                                All Rights Reserved for Tradinos Test
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php echo $__env->yieldContent('script'); ?>
<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<?php /**PATH F:\tradinos_tech_test\resources\views/layouts/app.blade.php ENDPATH**/ ?>