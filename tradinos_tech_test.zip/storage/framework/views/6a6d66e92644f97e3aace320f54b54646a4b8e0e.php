<table class="mb-0 table table-striped  dataTable dtr-inline">
    <thead>
    <tr>
        <th>#</th>
        <th>ID</th>
        <th>Deadline</th>
        <th>Created at</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>

    <?php $i = 1 ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i); ?></td>
            <td><?php echo e($row->id); ?></td>
            <td><?php echo e($row->deadline); ?></td>
            <td><?php echo e($row->created_at); ?></td>
            <td>
                <a class="mr-2" href="<?php echo e(route('tasks.show',$row->id)); ?>"><i class="fa fa-eye"></i></a>
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('tasks.edit',$row->id)); ?>"><i class="fa fa-edit"></i></a>

                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>

        <?php $i++ ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>


</table>
<?php if(empty($data)): ?>
    <div class="row text-center">
        <div class="col-md-12 alert-danger p-2 font-weight-bold">
            <span class=" ">There are no products yet!</span>
        </div>
    </div>
<?php endif; ?>
<div class="divider"></div>

<div class="pagination justify-content-center" style="margin-right: 10px;">
    <?php if($data->total() > 2): ?>

        <div class=" pd-flex ">
            <?php echo e($data->appends(request()->input())->links()); ?>

        </div>

    <?php endif; ?>
</div>

<?php /**PATH F:\tradinos_tech_test\resources\views/tasks_rows.blade.php ENDPATH**/ ?>