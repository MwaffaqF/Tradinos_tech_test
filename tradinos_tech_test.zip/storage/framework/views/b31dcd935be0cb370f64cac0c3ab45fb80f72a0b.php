<?php $__env->startSection('content'); ?>
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="fa fa-edit icon-gradient bg-warm-tradinos">
                        </i>
                    </div>
                    <div>Edit Task
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-content">
            <div class="">
                <div class="main-card mb-3 card">
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form class="" action="<?php echo e(route('tasks.update',$data['task']->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="position-relative row form-group"><label for="description"
                                                                                 class="col-sm-2 col-form-label">description</label>
                                <div class="col-sm-10"><textarea name="description" id="description"
                                                                 class="form-control"><?php echo e($data['task']->description); ?></textarea>
                                </div>
                            </div>
                            <div class="position-relative row form-group"><label for="deadline"
                                                                                 class="col-sm-2 col-form-label">Deadline
                                    Date</label>
                                <div class="col-sm-10"><input name="deadline" id="deadline" placeholder="deadline date"
                                                              type="date"
                                                              class="form-control" value="<?php echo e($data['task']->deadline); ?>">
                                </div>
                            </div>

                            <div class="position-relative row form-group"><label for="category"
                                                                                 class="col-sm-2 col-form-label">Categories</label>
                                <div class="col-sm-10">
                                    <div class="position-relative form-group">

                                        <select multiple="multiple" name="category[]" id="category"
                                                class="form-control multiple_select">
                                            <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"
                                                        <?php $__currentLoopData = $data['task']->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($category->id == $task_category->id): ?>  selected <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                ><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="position-relative row form-group"><label for="assign"
                                                                                 class="col-sm-2 col-form-label">Assign</label>
                                <div class="col-sm-10">
                                    <div class="position-relative form-group">

                                        <select name="assign" id="assign" class="form-control">
                                            <option></option>
                                            <?php $__currentLoopData = $data['assignees']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($assignee->id); ?>"
                                                        <?php if($data['task']->assignee->id == $assignee->id): ?>  selected <?php endif; ?>>
                                                    <?php echo e($assignee->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="position-relative row form-group "><label for="sub_task"
                                                                                  class="col-sm-2 col-form-label">Sub
                                    Tasks</label>
                                <div class="col-sm-10">
                                    <input name="sub_task[]"  placeholder="sub task" type="hidden"
                                           class="form-control mb-2" id="cloneable" >
                                    <?php $__currentLoopData = $data['task']->subTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subTask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input name="sub_task[]" placeholder="sub task" type="text"
                                               class="form-control mb-2"  value="<?php echo e($subTask->description); ?>" >
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="appendable"></div>
                                    <div class="btn btn-secondary bg-warm-tradinos btn-sm mt-2" id="btn_clone"><i
                                            class="fa fa-plus-circle"></i> Add Sub Task
                                    </div>

                                </div>
                            </div>

                            <div class="position-relative row form-check">
                                <div class="col-sm-10 offset-sm-2">
                                    <button class="btn btn-secondary bg-warm-tradinos btn-lg ">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(true); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            let i = 1;
            $("#btn_clone").click(function () {
                $('#cloneable').clone().each(function (j) {
                    this.id = "id" + i; // to keep it unique
                    this.placeholder = "sub task" + i;
                    this.type = 'text';
                    this.value = '';
                }).appendTo(".appendable");
                i++;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\tradinos_tech_test\resources\views/task/edit.blade.php ENDPATH**/ ?>