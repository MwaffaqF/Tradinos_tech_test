@extends('layouts.app')

@section('content')
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="fa fa-table icon-gradient bg-warm-tradinos">
                        </i>
                    </div>
                    <div>Tasks Table
                    </div>
                </div>
                @if (Route::has('login'))
                    @auth
                        <div class="page-title-actions">
                            <a href="{{route('tasks.create')}}" data-toggle="tooltip" title="create a new Task"
                               data-placement="bottom"
                               class="btn-shadow mr-3 btn bg-warm-tradinos text-white btn-lg font-weight-bold">Add Task
                                <i class="fa fa-plus-square text-white"></i>
                            </a>
                        </div>
                    @endauth
                @endif
            </div>
        </div>
        <div class="divider"></div>
        <div class="row">
            <div class="col-lg-12">
                <div class="main-card mb-3 card">
                    <div class="card-body" id="table_data">
                        @include('tasks_rows')
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {

            $(document).on('click', '.page-link', function (event) {
                event.preventDefault();
                var page = $(this).attr('href').split('page=')[1];
                fetch_data(page);
            });

            function fetch_data(page) {
                var _token = $("input[name=_token]").val();
                $.ajax({
                    url: "{{ route('tasks.get') }}",
                    method: "GET",
                    data: {
                        _token: "{{ csrf_token() }}",
                        page: page
                    },
                    success: function (data) {
                        $('#table_data').html(data);
                    }
                });
            }

        });
    </script>
@endsection
