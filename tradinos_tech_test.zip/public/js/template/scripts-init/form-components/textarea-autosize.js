// Forms Textarea Autosize

$( document ).ready(function() {

    $('textarea.autosize-input').textareaAutoSize();

});