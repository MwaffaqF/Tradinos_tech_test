// Form Wizard
$( document ).ready(function() {

    $('#smartwizard').smartWizard({
        selected: 0,
        transitionEffect: 'fade',
        toolbarSettings: {
            toolbarPosition: 'none',
        }
    });
});
