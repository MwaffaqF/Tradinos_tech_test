// Ladda loading buttons

$( document ).ready(function() {

    Ladda.bind('.ladda-button', {timeout: 2000});

});